    // --- 1. ADATOK ÉS KONSTANSOK ---
const nyersTerkep = 
    `.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,Y,Y,Y,.,.,.,.,.,.,B,B,.,.,.,B,B,B,.,.,.,.,.,.,.,.,.,.,.,.,.,.
.,.,.,.,.,.,.,.,#,.,.,.,.,.,.,.,.,.,.,Y,Y,Y,.,.,.,.,.,.,B,B,.,.,.,B,B,B,.,.,.,.,.,.,.,.,.,.,B,B,.,.
.,.,.,.,.,.,.,.,#,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,B,B,.,.,.,B,B,B,.,.,B,B,B,B,.,.,.,.,B,B,.,.
.,.,.,.,.,.,.,.,#,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,B,B,.,.,.,B,B,B,.,.,B,B,B,B,.,.,.,.,.,.,Y,Y
.,.,.,.,.,.,.,.,.,#,#,.,.,.,.,.,.,.,.,.,.,.,.,.,B,B,B,#,#,#,.,.,.,.,.,.,.,.,.,.,B,B,.,.,.,Y,Y,Y,Y,Y
.,.,.,.,.,.,.,.,.,#,#,.,.,.,.,.,.,.,.,.,.,.,.,B,B,B,B,.,.,.,.,.,.,.,B,B,B,.,.,G,G,G,G,.,.,Y,Y,Y,Y,Y
.,.,.,.,.,#,#,.,.,#,#,.,.,.,.,.,.,.,.,.,.,.,.,B,B,B,B,.,.,.,.,.,.,.,B,B,B,.,.,G,G,G,G,.,.,.,.,.,Y,Y
.,.,.,.,.,#,#,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,#,#,B,B,.,.,.,.,.,.,.,B,B,B,.,.,.,.,.,.,.,#,.,.,.,.,.
#,#,.,.,.,#,#,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,#,#,.,.,.,.,.,.,.,.,.,B,B,B,.,.,.,.,.,.,.,#,.,.,.,.,.
#,#,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,#,.,#,#,#,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,.,.,#,#,.
.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,#,.
.,Y,Y,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,B,B,B,B,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.
.,Y,Y,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,B,B,B,B,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.
.,Y,Y,.,.,.,.,B,B,.,.,.,.,.,.,.,.,.,.,.,.,.,G,G,G,B,B,B,.,.,.,.,.,.,.,#,#,#,B,B,B,B,.,.,.,.,.,.,.,.
.,.,.,.,.,.,.,B,B,.,.,.,Y,Y,Y,.,.,.,.,.,.,.,G,#,G,.,.,.,#,#,#,.,.,.,.,.,#,#,B,B,B,Y,Y,.,.,.,.,.,.,.
.,.,.,.,.,.,.,B,B,.,.,G,Y,Y,Y,.,.,.,.,#,.,.,.,#,.,.,.,.,#,#,#,.,.,.,.,Y,Y,Y,Y,.,.,Y,Y,.,.,.,.,.,.,.
.,.,.,.,.,.,.,B,B,.,.,G,G,G,B,.,.,.,.,#,.,.,.,.,.,.,.,.,#,#,#,.,.,.,.,Y,Y,Y,Y,.,.,Y,Y,.,.,.,.,.,.,.
#,.,.,.,.,.,.,.,.,.,.,B,B,B,B,.,.,.,.,#,.,.,.,.,.,.,.,.,G,G,G,.,.,.,.,Y,Y,Y,Y,.,.,.,.,.,.,.,.,.,.,.
#,.,.,.,.,.,.,.,.,.,.,B,B,B,B,.,.,.,.,.,.,.,.,.,.,.,.,.,G,G,G,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.
#,.,.,.,.,.,.,.,.,.,.,B,B,B,B,.,.,.,.,.,.,.,.,.,.,.,.,.,G,G,G,.,.,.,.,.,.,.,.,.,.,.,.,.,#,.,.,G,G,.
B,B,B,.,.,.,.,.,.,#,.,#,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,.,.,G,G,.
B,B,B,.,.,.,.,.,.,#,.,#,.,.,.,.,.,.,.,.,.,.,.,B,B,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,.,.,G,G,.
B,B,B,.,.,.,.,.,.,#,.,#,.,.,.,.,.,.,.,.,.,.,.,B,B,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,G,G,.
B,B,B,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,B,B,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#
.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,#,#,.,.,.,.,.,.,.,#
.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,#,#,.,.,.,.,.,.,.,.,.,#,#,#,.,.,.,.,.,.,.,#
.,.,.,.,.,.,.,.,.,.,Y,Y,Y,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,#,#,.,.,.,.,.,.,.,.,.,Y,Y,.,.,.,.,.,.,.,.,.
.,.,.,.,.,#,#,#,.,.,Y,Y,Y,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,Y,Y,.,.,.,.,.,.,.,.,.
.,.,.,G,G,#,#,#,.,.,Y,#,#,B,B,.,.,.,.,.,.,.,#,#,#,.,.,.,.,.,.,.,.,.,.,.,.,.,.,Y,Y,.,.,#,.,.,.,.,.,.
.,.,.,G,G,#,#,#,.,.,.,#,#,B,B,.,.,#,.,.,.,.,#,#,.,.,.,.,.,.,.,.,#,#,B,B,.,.,.,Y,Y,.,.,#,.,#,#,#,.,.
.,.,.,G,G,.,.,.,.,#,#,#,#,#,B,.,.,#,.,.,.,.,#,#,.,.,.,.,.,.,#,.,#,#,B,B,.,.,.,.,.,.,.,.,.,.,.,.,.,.
.,.,.,.,.,.,.,.,.,.,.,.,.,B,B,.,.,.,.,.,.,.,.,#,#,#,.,.,.,.,#,.,#,#,B,#,.,.,.,.,.,.,.,.,.,.,.,.,#,#
B,B,B,B,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,#,#,.,.,.,.,.,.,.,.,S,#,.,.,.,.,.,.,.,.,.,.,.,.,.,.
B,B,B,B,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,#,#,.,.,.,.,.,.,.,.,.,#,.,.,.,.,.,.,.,.,.,.,.,.,.,.
B,B,B,B,.,.,.,.,#,.,.,.,.,.,.,B,B,B,.,.,.,.,.,.,.,#,.,.,.,.,.,.,.,.,.,.,.,.,.,B,B,B,B,B,B,.,.,.,#,#
B,Y,Y,Y,.,.,.,.,.,.,.,.,.,.,.,B,B,B,.,.,.,.,.,.,.,#,.,#,#,#,.,.,.,.,.,.,.,.,.,B,B,B,B,B,#,.,.,.,#,#
.,Y,Y,Y,.,.,.,#,#,#,.,.,.,.,.,.,.,.,.,.,.,.,#,#,#,.,.,#,#,#,.,.,.,.,.,.,.,.,.,.,.,B,B,B,#,Y,Y,Y,#,#
.,Y,Y,#,B,.,.,.,.,.,G,G,G,.,.,.,.,.,G,G,G,.,#,#,#,.,B,#,#,#,.,.,.,.,.,.,.,.,.,.,.,B,B,B,Y,Y,Y,Y,.,.
.,Y,Y,#,B,.,#,.,.,.,G,G,G,.,.,.,.,.,G,G,G,.,#,#,#,.,B,B,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,Y,Y,Y,Y,.,.
.,.,B,B,B,.,#,.,.,.,G,G,G,.,#,.,.,.,.,.,.,.,.,.,.,.,B,B,.,.,.,.,.,.,#,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.
.,.,.,.,.,.,#,.,.,.,.,.,.,.,#,#,.,.,#,.,.,.,.,.,.,.,.,.,G,G,G,.,.,.,#,.,.,.,.,.,.,.,.,.,G,G,G,G,.,.
.,.,.,.,#,#,#,.,.,.,.,.,.,.,#,#,#,.,#,.,.,.,.,.,.,.,.,.,G,G,G,.,.,.,.,.,.,.,.,.,#,#,#,.,G,G,G,G,.,.
.,.,.,.,#,#,#,.,.,.,.,.,.,.,#,#,#,B,.,.,.,.,.,.,.,.,.,.,G,G,G,G,G,.,G,G,.,.,.,.,.,.,.,.,G,G,G,G,.,.
.,.,.,.,#,#,#,.,.,.,.,.,.,.,B,B,B,B,.,.,.,.,.,.,.,.,.,.,G,G,G,G,G,.,G,G,.,.,.,.,#,#,.,.,.,.,.,.,.,.
.,.,.,.,.,.,.,#,#,#,.,.,#,#,.,.,#,.,.,.,.,.,.,.,.,.,.,.,Y,Y,Y,Y,.,.,G,G,.,.,.,.,.,G,G,G,.,.,.,.,.,.
.,.,.,G,G,G,.,.,.,.,.,.,#,#,.,.,#,.,.,.,.,.,.,.,.,.,.,.,Y,Y,Y,Y,.,.,.,.,.,.,.,.,.,G,G,G,.,.,.,.,.,.
.,.,.,G,G,G,.,.,.,.,.,.,.,.,.,.,#,.,.,.,.,.,.,.,.,.,.,.,Y,Y,Y,Y,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.
.,.,.,G,G,G,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,#,#,.,.,.,.
.,.,.,G,G,G,.,.,.,.,.,.,G,G,G,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,#,#,.,.,.,.
.,.,.,.,.,.,.,.,.,.,.,.,G,G,G,.,.,.,.,.,#,#,#,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,#,#,#,.,.,.,.
`;
    
            let terkepRacs = []; //2D tomb lesz (x,y)
            let asvanyLista = []; //2D asvanyok koordinataja es tipusa
            let kezdoPont = {x: 0, y: 0}; //Kezdopont koordinataja
            let marsJaro = { //Mars jaro adatai
                x: 0, y: 0, akku: 100,
                keszlet: {B:0, Y:0, G:0},
                megtettTav: 0, idoLepesek: 0, maxLepesek: 0,
                utvonal: [], jelenlegiCel: null, banyaszikE: false,
                hazaTerE: false
            };
            let szimulaciosIdozito = null; 

            //Fajl beolvasasa es terkep legeneralasa
            function terkepBetoltese() {
                const sorok = nyersTerkep.trim().split('\n'); //Nyersanyag formazasa
                const terkepElem = document.getElementById('mars-terkep'); //Terkep elem meghatarozasa
                terkepElem.innerHTML = ''; //Elozo futtatas visszaallitasa
                terkepRacs = []; //Elozo futtatas visszaallitasa
                asvanyLista = []; //Elozo futtatas visszaallitasa
    
                sorok.forEach((sor, y) => { 
                    const cellak = sor.split(',');
                    let sorAdat = [];
                    cellak.forEach((karakter, x) => { //Cellak letrehozasa, meghatarozasa
                        sorAdat.push(karakter);
                        const div = document.createElement('div');
                        div.className = `cella ${karakterOsztaly(karakter)}`;
                        div.id = `c-${x}-${y}`;
                        terkepElem.appendChild(div);
    
                        if (['B', 'Y', 'G'].includes(karakter)) asvanyLista.push({x, y, tipus: karakter}); //Ha asvany, akkor hozzaadjuk az asvanyokhoz
                        if (karakter === 'S') { kezdoPont = {x, y}; marsJaro.x = x; marsJaro.y = y; } //Ha ez a kezdopont akkor beallitjuk
                    });
                    terkepRacs.push(sorAdat); //Sor hozzaadaja a terkephez
                });
                megjelenitesFrissitese(); //Frissitjuk az oldalt
                naplozas(`[RENDSZER] Térkép betöltve, Rover a bázison (${kezdoPont.x}, ${kezdoPont.y})`); //Logolas
            }
    
            function karakterOsztaly(k) { //Cella osztalyanak beallitasahoz
                if(k === '.') return 'felszin';
                if(k === '#') return 'akadaly';
                if(k === 'B') return 'kek';
                if(k === 'Y') return 'sarga';
                if(k === 'G') return 'zold';
                if(k === 'S') return 'start';
                return 'felszin';
            }
    
            function megjelenitesFrissitese() {
                document.querySelectorAll('.jaro').forEach(el => el.classList.remove('jaro')); //Rover regi helyenek torlese
                const cella = document.getElementById(`c-${marsJaro.x}-${marsJaro.y}`); //Uj hely beallitsasa
                if(cella) cella.classList.add('jaro'); //Uj hely beallitsasa
    
                document.querySelectorAll('.utvonal').forEach(el => el.classList.remove('utvonal')); // elozo utvonal torlese
                marsJaro.utvonal.forEach(p => { //Uj utvonal kirajzolasa
                    const pc = document.getElementById(`c-${p.x}-${p.y}`); // Cella megrekesese
                    if(pc && !pc.classList.contains('jaro')) pc.classList.add('utvonal'); //Cella valtoztatasa
                });
                
                //Napszakkal, idovel kapcsolatos beallitasok
                const nappalVan = (marsJaro.idoLepesek % 48) < 32;
                document.body.className = nappalVan ? '' : 'ejszaka';
                const orak = Math.floor(marsJaro.idoLepesek / 2);
                const percek = (marsJaro.idoLepesek % 2 === 0) ? "00" : "30";
            
                //Dashboard frissitese
                document.getElementById('kijelzo-ido').innerText = `${String(orak).padStart(2,'0')}:${percek} (${nappalVan ? 'Nappal' : 'Éjszaka'})`;
                document.getElementById('kijelzo-akku').innerText = `${marsJaro.akku}%`;
                document.getElementById('kijelzo-pozicio').innerText = `X:${marsJaro.x} Y:${marsJaro.y}`;
                document.getElementById('kijelzo-tavolsag').innerText = `${marsJaro.megtettTav} blokk`;
                document.getElementById('szamlalo-kek').innerText = marsJaro.keszlet.B;
                document.getElementById('szamlalo-sarga').innerText = marsJaro.keszlet.Y;
                document.getElementById('szamlalo-zold').innerText = marsJaro.keszlet.G;
            }
    
            function naplozas(uzenet) {
                const doboz = document.getElementById('esemeny-naplo');
                const p = document.createElement('p');
                const o = String(Math.floor(marsJaro.idoLepesek / 2)).padStart(2,'0'); //Ido formazasa
                const p_perc = (marsJaro.idoLepesek % 2 === 0) ? "00" : "30"; //Percek szamitasa
                p.innerHTML = `<span class="ido">[${o}:${p_perc}]</span> ${uzenet}`; //Uzenet megadasa
                doboz.prepend(p); //A log vegere rakja
            }
    
            function aCsillag(start, cel) {
                const nyiltHalmaz = [ {x: start.x, y: start.y, g: 0, f: heurisztika(start, cel), szulo: null} ];
                const zartHalmaz = new Set();
                
                while(nyiltHalmaz.length > 0) {
                    nyiltHalmaz.sort((a,b) => a.f - b.f);
                    const jelenlegi = nyiltHalmaz.shift();
                    
                    if (jelenlegi.x === cel.x && jelenlegi.y === cel.y) {
                        let ut = [];
                        let temp = jelenlegi;
                        while(temp.szulo) { ut.push({x: temp.x, y: temp.y}); temp = temp.szulo; }
                        return ut.reverse();
                    }
    
                    zartHalmaz.add(`${jelenlegi.x},${jelenlegi.y}`);
    
                    const iranyok = [[0,-1],[0,1],[-1,0],[1,0],[-1,-1],[1,-1],[-1,1],[1,1]];
                    for(let d of iranyok) {
                        const nx = jelenlegi.x + d[0], ny = jelenlegi.y + d[1];
                        if(nx < 0 || ny < 0 || nx >= 50 || ny >= 50) continue;
                        if(terkepRacs[ny][nx] === '#') continue; 
                        if(zartHalmaz.has(`${nx},${ny}`)) continue;
    
                        const proba_g = jelenlegi.g + 1;
                        let szomszed = nyiltHalmaz.find(n => n.x === nx && n.y === ny);
                        
                        if(!szomszed) {
                            nyiltHalmaz.push({x: nx, y: ny, g: proba_g, f: proba_g + heurisztika({x:nx,y:ny}, cel), szulo: jelenlegi});
                        } else if (proba_g < szomszed.g) {
                            szomszed.g = proba_g;
                            szomszed.f = proba_g + heurisztika({x:nx,y:ny}, cel);
                            szomszed.szulo = jelenlegi;
                        }
                    }
                }
                return [];
            }
    
            function hazaUtKalkulalasa(tavolsag, jelenlegiAkku, jelenlegiTick) {
                let lepesek = 0;
                let aktAkku = jelenlegiAkku;
                let tickSzamlalo = jelenlegiTick;
                let hatralevoTav = tavolsag;
    
                while (hatralevoTav > 0) {
                    const nappalVan = (tickSzamlalo % 48) < 32;
                    const toltes = nappalVan ? 10 : 0;
                    
                    let v = 1;
                    if (hatralevoTav >= 3 && aktAkku > 40) v = 3;
                    else if (hatralevoTav >= 2 && aktAkku > 20) v = 2;
                    
                    const energiaKoltseg = 2 * (v * v);
                    const varhatoAkku = aktAkku - energiaKoltseg + toltes;
    
                    if (varhatoAkku < 0) {
                        aktAkku = Math.min(100, aktAkku - 1 + toltes);
                    } else {
                        aktAkku = Math.min(100, varhatoAkku);
                        hatralevoTav -= v;
                    }
                    lepesek++;
                    tickSzamlalo++;
                    
                    if(lepesek > 500) break; // Végtelen ciklus ellen
                }
                return lepesek;
            }
    
            function heurisztika(a, b) { return Math.max(Math.abs(a.x - b.x), Math.abs(a.y - b.y)); }
    
            function legkozelebbiAsvany() {
                let legjobbCel = null;
                let minTav = Infinity;
                
                for(let asvany of asvanyLista) {
                    const hTav = heurisztika(marsJaro, asvany);
                    if (hTav > minTav) continue; 
                    
                    const p = aCsillag(marsJaro, asvany);
                    if(p.length > 0 && p.length < minTav) {
                        minTav = p.length;
                        legjobbCel = { cel: asvany, ut: p };
                    }
                }
                return legjobbCel;
            }
    
            function szimulaciosLepes() {
            if(marsJaro.idoLepesek >= marsJaro.maxLepesek || (marsJaro.x == kezdoPont.x && marsJaro.y == kezdoPont.y && asvanyLista.length === 0)) {
                naplozas("A szimulációs időkeret lejárt. Misszió vége.");
                clearInterval(szimulaciosIdozito);
                document.getElementById('gomb-inditas').disabled = false;
                return;
            }

            const nappalVan = (marsJaro.idoLepesek % 48) < 32;
            let toltes = nappalVan ? 10 : 0;
            let allapotSzoveg = "Tétlen";
            let sebessegSzoveg = "0 blokk/fél óra";

            // 1. Végleges visszatérés ellenőrzése (időkorlát miatt)
            if (!marsJaro.hazaTerE) {
                const utHaza = aCsillag(marsJaro, kezdoPont);
                const szuksegesTickek = hazaUtKalkulalasa(utHaza.length, marsJaro.akku, marsJaro.idoLepesek);
                const hatralevoTickek = marsJaro.maxLepesek - marsJaro.idoLepesek;
                
                if (hatralevoTickek <= szuksegesTickek + 1 && (marsJaro.x !== kezdoPont.x || marsJaro.y !== kezdoPont.y)) {
                    naplozas(`[Kritikus] VÉGLEGES visszatérés a bázisra! (Szükséges idő: ${szuksegesTickek} tick, Hátralévő: ${hatralevoTickek})`);
                    marsJaro.hazaTerE = true; 
                    marsJaro.jelenlegiCel = kezdoPont;
                    marsJaro.utvonal = utHaza;
                    marsJaro.banyaszikE = false;
                }
            } 
            
            // 2. Sikeres hazaérkezés lekezelése
            if (marsJaro.hazaTerE && marsJaro.x === kezdoPont.x && marsJaro.y === kezdoPont.y) {
                marsJaro.akku = Math.min(100, marsJaro.akku + toltes - 1); // Standby fogyasztás és töltés bázison
                document.getElementById('kijelzo-allapot').innerText = "Misszió sikeres (Bázison várakozik)";
                document.getElementById('kijelzo-sebesseg').innerText = "0 blokk/fél óra";
                marsJaro.idoLepesek++;
                megjelenitesFrissitese();
                return; 
            }

            // 3. Fő cselekvési logika
            if (marsJaro.banyaszikE) {
                marsJaro.akku = Math.min(100, marsJaro.akku - 2 + toltes);
                const cellaErtek = terkepRacs[marsJaro.y][marsJaro.x];
                marsJaro.keszlet[cellaErtek]++;
                
                terkepRacs[marsJaro.y][marsJaro.x] = '.';
                asvanyLista = asvanyLista.filter(m => !(m.x === marsJaro.x && m.y === marsJaro.y));
                const cellaDiv = document.getElementById(`c-${marsJaro.x}-${marsJaro.y}`);
                cellaDiv.className = 'cella felszin jaro';
                
                naplozas(`Bányászat kész: 1 db ${cellaErtek === 'B'?'Kék':cellaErtek === 'Y'?'Sárga':'Zöld'}.`);
                marsJaro.banyaszikE = false;
                marsJaro.jelenlegiCel = null;
                
                // Ha hazatérésben van (mert pl közben jött rá), újraszámolja az útvonalat
                if (marsJaro.hazaTerE) {
                    const utHaza = aCsillag(marsJaro, kezdoPont);
                    marsJaro.utvonal = utHaza;
                    naplozas(`Bányászat után hazatérés kezdődik. Távolság: ${utHaza.length} blokk.`);
                }
                
                allapotSzoveg = "Bányászik";

            } else {
                // Ha nincs bányászat, MOZOGNUNK KELL.
                
                // 3/A. Ha nincs megtervezett útvonal, most tervezzük meg
                if (marsJaro.utvonal.length === 0 && !marsJaro.hazaTerE) {
                    const legjobb = legkozelebbiAsvany();
                    if (legjobb) {
                        marsJaro.jelenlegiCel = legjobb.cel;
                        marsJaro.utvonal = legjobb.ut;
                        naplozas(`Új célpont kiválasztva. Távolság: ${legjobb.ut.length} blokk.`);
                    } else {
                        // HA NINCS TÖBB ELÉRHETŐ ÁSVÁNY -> IRÁNY HAZA!
                        naplozas(`Minden elérhető ásvány kibányászva. Visszatérés a bázisra!`);
                        marsJaro.hazaTerE = true;
                        marsJaro.jelenlegiCel = kezdoPont;
                        marsJaro.utvonal = aCsillag(marsJaro, kezdoPont);
                    }
                }

                // 3/B. Ha van útvonal (akár a régi, akár most számoltuk ki az előző blokkban), azonnal elindulunk rajta
                if (marsJaro.utvonal.length > 0) {
                    let v = 1;
                    if (marsJaro.utvonal.length >= 3 && marsJaro.akku > 40) v = 3;
                    else if (marsJaro.utvonal.length >= 2 && marsJaro.akku > 20) v = 2;
                    
                    const energiaKoltseg = 2 * (v * v); 
                    const varhatoAkku = marsJaro.akku - energiaKoltseg + toltes;

                    if (varhatoAkku < 0) {
                        marsJaro.akku = Math.min(100, marsJaro.akku - 1 + toltes);
                        naplozas(`[Veszély] Alacsony akku (${marsJaro.akku}%), Standby üzemmód.`);
                        allapotSzoveg = "Standby (Töltés)";
                    } else {
                        marsJaro.akku = Math.min(100, varhatoAkku);
                        let megtettLepes = 0;
                        for(let i = 0; i < v; i++) {
                            if(marsJaro.utvonal.length === 0) break;
                            const kovetkezoLepes = marsJaro.utvonal.shift();
                            marsJaro.x = kovetkezoLepes.x; marsJaro.y = kovetkezoLepes.y;
                            megtettLepes++;
                            marsJaro.megtettTav++;
                        }
                        
                        sebessegSzoveg = `${megtettLepes} blokk/fél óra`;
                        allapotSzoveg = marsJaro.hazaTerE ? "Hazatérés..." : "Úton...";

                        // Ha pont most értük el a célpontot
                        if (marsJaro.utvonal.length === 0 && marsJaro.jelenlegiCel && !marsJaro.hazaTerE && terkepRacs[marsJaro.y][marsJaro.x] !== '.' && terkepRacs[marsJaro.y][marsJaro.x] !== 'S') {
                            marsJaro.banyaszikE = true;
                            naplozas(`Célpont elérve.`);
                        }
                    }
                } else {
                    // Biztonsági ág, ha sehova nem tud menni (pl. már otthon van vagy beragadt)
                    marsJaro.akku = Math.min(100, marsJaro.akku - 1 + toltes);
                    allapotSzoveg = "Standby (Nincs hova menni)";
                }
            }

            document.getElementById('kijelzo-allapot').innerText = allapotSzoveg;
            document.getElementById('kijelzo-sebesseg').innerText = sebessegSzoveg;
            marsJaro.idoLepesek++;
            megjelenitesFrissitese();
        }
            //Misszio Inditasa gomb - kattintas
            document.getElementById('gomb-inditas').addEventListener('click', () => {
                const orak = parseInt(document.getElementById('bemenet-ido').value); //Megadott ido beolvasasa
                if(orak < 24) return alert("Az időkeretnek legalább 24 órának kell lennie!"); //Minimum ido
                
                terkepBetoltese();
                //Rover alap ertekei
                marsJaro.akku = 100;
                marsJaro.idoLepesek = 0;
                marsJaro.maxLepesek = orak * 2; 
                marsJaro.megtettTav = 0;
                marsJaro.keszlet = {B:0, Y:0, G:0};
                marsJaro.utvonal = []; 
                marsJaro.jelenlegiCel = null; 
                marsJaro.banyaszikE = false;
                marsJaro.hazaTerE = false; 
                document.getElementById('esemeny-naplo').innerHTML = '';
                
                document.getElementById('gomb-inditas').disabled = true;
                naplozas(`[RENDSZER] Misszió indítva! Időkeret: ${orak} óra.`);
                
                if(szimulaciosIdozito) clearInterval(szimulaciosIdozito);
                szimulaciosIdozito = setInterval(szimulaciosLepes, 1); 
            });

            terkepBetoltese();

            document.getElementById('gomb-letoltes').addEventListener('click', function() {
            const logDiv = document.getElementById('esemeny-naplo');
            let logSzoveg = logDiv.innerText || logDiv.textContent;
 
            const blob = new Blob([logSzoveg], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
 
            const a = document.createElement('a');
            a.href = url;
            a.download = 'log.txt';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
 
            URL.revokeObjectURL(url);
        });